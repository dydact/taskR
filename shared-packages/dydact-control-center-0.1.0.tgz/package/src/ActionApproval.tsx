"use client";

import { useMemo } from "react";
import { useCopilotAction } from "@copilotkit/react-core";

export type ActionApprovalHandler = (actionName: string, approved: boolean) => Promise<void> | void;

export type ActionApprovalProps = {
  onApprove?: ActionApprovalHandler;
};

type ApprovalCardProps = {
  actionName: string;
  args: Record<string, unknown> | null | undefined;
  onRespond: (decision: boolean) => void;
  isExecuting: boolean;
};

function ApprovalCard({ actionName, args, onRespond, isExecuting }: ApprovalCardProps) {
  const content = useMemo(() => {
    if (!args) return "{}";
    try {
      return JSON.stringify(args, null, 2);
    } catch (error) {
      console.error("Failed to serialise action args", error);
      return String(args);
    }
  }, [args]);

  return (
    <div className="glass-outline space-y-3 rounded-3xl bg-white/80 p-4 text-sm text-slate-600 shadow-sm dark:bg-slate-900/70 dark:text-slate-200">
      <h3 className="text-base font-semibold text-slate-900 dark:text-white">Approve action: {actionName}</h3>
      <pre className="max-h-48 overflow-y-auto rounded-2xl bg-slate-900/70 p-3 text-xs text-slate-100">
        {content}
      </pre>
      <div className="flex gap-3">
        <button
          type="button"
          onClick={() => onRespond(true)}
          disabled={isExecuting}
          className="btn-primary flex-1"
        >
          Approve
        </button>
        <button
          type="button"
          onClick={() => onRespond(false)}
          disabled={isExecuting}
          className="btn-secondary flex-1"
        >
          Reject
        </button>
      </div>
    </div>
  );
}

function withApprovalHandler(
  actionName: string | null | undefined,
  args: Record<string, unknown> | null | undefined,
  status: string,
  respond: ((response?: Record<string, unknown>) => void) | undefined,
  onApprove?: ActionApprovalHandler
): JSX.Element {
  const safeAction = actionName ?? "automation";
  const handleRespond = async (approved: boolean) => {
    try {
      if (onApprove) {
        await onApprove(safeAction, approved);
      }
    } finally {
      respond?.({ approved });
    }
  };

  return (
    <ApprovalCard
      actionName={safeAction}
      args={args}
      isExecuting={status === "executing" || status === "inProgress"}
      onRespond={handleRespond}
    />
  );
}

export function ActionApproval({ onApprove }: ActionApprovalProps) {
  useCopilotAction({
    name: "toolfront.ask.umbra.computer_use",
    renderAndWaitForResponse: (payload) =>
      withApprovalHandler(
        "toolfront.ask.umbra.computer_use",
        (payload as unknown as { args: Record<string, unknown> }).args,
        (payload as unknown as { status: string }).status,
        (payload as unknown as { respond?: (data?: Record<string, unknown>) => void }).respond,
        onApprove
      ),
  });

  useCopilotAction({
    name: "*",
    renderAndWaitForResponse: (payload) =>
      withApprovalHandler(
        (payload as unknown as { name?: string }).name,
        (payload as unknown as { args: Record<string, unknown> }).args,
        (payload as unknown as { status: string }).status,
        (payload as unknown as { respond?: (data?: Record<string, unknown>) => void }).respond,
        onApprove
      ),
  });

  return null;
}
