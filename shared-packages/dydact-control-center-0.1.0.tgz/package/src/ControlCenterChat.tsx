"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import clsx from "clsx";
import { CopilotKit, useCopilotChat, useCopilotContext } from "@copilotkit/react-core";
import { CopilotChat } from "@copilotkit/react-ui";
import { MessageRole, TextMessage } from "@copilotkit/runtime-client-gql";

import { ActionApproval, ActionApprovalHandler } from "./ActionApproval";
import type { ControlCenterChatOptions, ServiceDefinition } from "./types";

const BASE_INSTRUCTIONS = `You are the dydact control-center assistant. Keep answers concise, reference ToolFront telemetry when relevant, and request human approval for guarded automations.`;
const DEFAULT_RUNTIME = "/api/copilot";
const DEFAULT_APPROVAL_ENDPOINT = "/api/actions/approve";
const DEFAULT_AVATAR = "https://static.dydact.ai/brand/dydactlogocard.png";

function buildDefaultInstructions(service: ServiceDefinition): string {
  switch (service.key) {
    case "taskr":
      return `${BASE_INSTRUCTIONS} Focus on TaskR queues, deptX salvage automations, and memPODS ingestion telemetry.`;
    case "scrAIv":
      return `${BASE_INSTRUCTIONS} Surface compliance guardrails, claims reconciliation statuses, and payroll QA context.`;
    case "vocols":
      return `${BASE_INSTRUCTIONS} Highlight Telnyx call metrics, operator handoffs, and voice QA alerts.`;
    case "deptx":
      return `${BASE_INSTRUCTIONS} Summarise deptX salvage runs, n8n workflows, and replay readiness.`;
    case "toolfront":
      return `${BASE_INSTRUCTIONS} Act as the ToolFront authority—manifest drift, provider contracts, and graph feed status.`;
    default:
      return BASE_INSTRUCTIONS;
  }
}

export type ControlCenterChatProps = {
  service: ServiceDefinition;
  onSessionChange?: (sessionId: string) => void;
} & ControlCenterChatOptions;

const SessionBridge = ({ onSessionChange }: { onSessionChange?: (sessionId: string) => void }) => {
  const { threadId } = useCopilotContext();
  const lastSession = useRef<string | undefined>();

  useEffect(() => {
    if (!threadId || lastSession.current === threadId) return;
    lastSession.current = threadId;
    onSessionChange?.(threadId);
  }, [threadId, onSessionChange]);

  return null;
};

type DocIngestEventDetail = {
  documentId?: string | null;
  sessionId?: string | null;
  filename?: string | null;
};

const DOC_EVENT_NAME = "dydact:doc-ingested";

const DocIngestAutomation = () => {
  const { appendMessage } = useCopilotChat();
  const processed = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (typeof window === "undefined") return;
    const handler = (event: Event) => {
      const custom = event as CustomEvent<DocIngestEventDetail>;
      const detail = custom.detail;
      if (!detail) return;

      const docId = detail.documentId ?? undefined;
      const session = detail.sessionId ?? undefined;
      const key = `${docId ?? "unknown"}:${session ?? "none"}`;
      if (processed.current.has(key)) return;
      processed.current.add(key);

      const name = detail.filename ? `“${detail.filename}”` : docId ? `document ${docId}` : "the new document";
      const prompt = [
        `A document ingest just completed${session ? ` in session ${session}` : ""}.`,
        `Provide a concise executive summary for ${name}.`,
        `List the top 3 insights and identify any follow-up actions the operator should take.`,
        docId
          ? `Use the doc.ingest search tool scoped to document id ${docId} before responding, and reference that id if the operator asks for provenance.`
          : "",
      ]
        .filter(Boolean)
        .join(" ");

      const message = new TextMessage({
        id: `auto-doc-${Date.now()}`,
        role: MessageRole.User,
        content: prompt,
      });

      void appendMessage(message);
    };

    window.addEventListener(DOC_EVENT_NAME, handler as EventListener);
    return () => window.removeEventListener(DOC_EVENT_NAME, handler as EventListener);
  }, [appendMessage]);

  return null;
};

export function ControlCenterChat({
  service,
  runtimeUrl,
  tenantId,
  headers,
  approvalEndpoint = DEFAULT_APPROVAL_ENDPOINT,
  avatarUrl = DEFAULT_AVATAR,
  instructions,
  description,
  showDevConsole = false,
  threadId,
  onSessionChange,
}: ControlCenterChatProps) {
  const [modelName, setModelName] = useState<string | null>(null);
  const resolvedInstructions = useMemo(() => instructions ?? buildDefaultInstructions(service), [instructions, service]);
  const resolvedDescription = description ?? "Ask for telemetry, trigger automations, or route HITL approvals.";
  const runtime = runtimeUrl ?? DEFAULT_RUNTIME;

  const runtimeHeaders = useMemo(() => {
    const base: Record<string, string> = { "x-dydact-service": service.key };
    if (tenantId) {
      base["x-tenant-id"] = tenantId;
    }
    if (headers) {
      Object.assign(base, headers);
    }
    return base;
  }, [headers, service.key, tenantId]);

  const handleApprove: ActionApprovalHandler = async (actionName, approved) => {
    try {
      await fetch(approvalEndpoint, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          ...runtimeHeaders,
        },
        body: JSON.stringify({ name: actionName, approved }),
      });
    } catch (error) {
      console.error("Failed to confirm action", error);
    }
  };

  useEffect(() => {
    const controller = new AbortController();
    const tenant = tenantId ?? process.env.NEXT_PUBLIC_TENANT_ID ?? "demo";
    fetch("/api/insight/config", { headers: { "x-tenant-id": tenant }, signal: controller.signal })
      .then((r) => r.json())
      .then((cfg) => {
        try {
          const profiles = cfg?.profiles || {};
          const reasoning: string[] = profiles["reasoning"] || [];
          const first = Array.isArray(reasoning) && reasoning.length ? reasoning[0] : null;
          if (first) setModelName(first);
        } catch { /* ignore */ }
      })
      .catch(() => void 0);
    return () => controller.abort();
  }, [tenantId, service.key]);

  return (
    <CopilotKit
      runtimeUrl={runtime}
      headers={runtimeHeaders}
      properties={{ client: "dydact-platform", surface: service.key }}
      threadId={threadId}
      showDevConsole={showDevConsole}
    >
      <ActionApproval onApprove={handleApprove} />
      <SessionBridge onSessionChange={onSessionChange} />
      <DocIngestAutomation />
      <div className="copilot-shell flex h-full flex-col rounded-[32px] border border-white/10 bg-[#0b0f1f] p-4 text-white shadow-[0_40px_120px_rgba(10,12,24,0.6)]">
        <div className="glass-header mb-4 flex items-center justify-center rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
          {modelName ? (
            <span className="rounded-full bg-white/10 px-4 py-1.5 text-[11px] font-semibold normal-case tracking-[0.15em] text-white shadow-sm">
              {modelName}
            </span>
          ) : (
            <span className="rounded-full bg-white/5 px-4 py-1.5 text-[11px] font-semibold normal-case tracking-[0.15em] text-white/70">
              Resolving model…
            </span>
          )}
        </div>
        <div className="flex-1 overflow-hidden rounded-3xl border border-white/10 bg-black/20">
          <CopilotChat
            className={clsx("copilot-kit-portal", "flex h-full flex-col")}
            instructions={resolvedInstructions}
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            labels={{ title: `${service.label} Copilot`, description: resolvedDescription } as any}
            suggestions={"none" as any}
          />
        </div>
      </div>
    </CopilotKit>
  );
}

export default ControlCenterChat;
