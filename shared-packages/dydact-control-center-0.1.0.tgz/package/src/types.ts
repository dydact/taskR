import type { ReactNode } from "react";

export type ServiceDefinition = {
  key: string;
  label: string;
  description?: string;
  accentClass?: string;
  icon?: ReactNode;
  overlay?: ReactNode;
};

export type ControlCenterChatOptions = {
  /** Optional absolute or relative runtime endpoint for CopilotKit */
  runtimeUrl?: string;
  /** Optional tenant identifier header */
  tenantId?: string;
  /** Custom request headers forwarded to CopilotKit runtime */
  headers?: Record<string, string>;
  /** Endpoint that receives action approvals */
  approvalEndpoint?: string;
  /** Avatar image URL rendered above the chat */
  avatarUrl?: string;
  /** Override default instructions string */
  instructions?: string;
  /** Override default description text */
  description?: string;
  /** Toggle CopilotKit dev console */
  showDevConsole?: boolean;
  /** Optional externally managed thread identifier */
  threadId?: string;
};
