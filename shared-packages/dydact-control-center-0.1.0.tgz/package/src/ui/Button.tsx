"use client";

import clsx from "clsx";
import type { ButtonHTMLAttributes, ReactNode } from "react";

export type ButtonVariant = "primary" | "secondary" | "ghost";

export type ButtonProps = {
  variant?: ButtonVariant;
  icon?: ReactNode;
  loading?: boolean;
} & ButtonHTMLAttributes<HTMLButtonElement>;

const VARIANT_CLASSNAMES: Record<ButtonVariant, string> = {
  primary:
    "bg-[#2b2d3c] text-white hover:bg-[#3b3d50] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#8f9bff]",
  secondary:
    "border border-white/20 bg-white/5 text-white/80 hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/50",
  ghost:
    "text-white/60 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/40",
};

export function Button({ variant = "primary", icon, loading, className, children, disabled, ...props }: ButtonProps) {
  return (
    <button
      type="button"
      className={clsx(
        "inline-flex items-center gap-2 rounded-full px-5 py-2 text-sm font-semibold transition",
        VARIANT_CLASSNAMES[variant],
        loading ? "opacity-70" : "",
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {icon}
      {children}
    </button>
  );
}
