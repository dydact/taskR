import clsx from "clsx";
import type { HTMLAttributes } from "react";

export type SectionDividerProps = {
  label?: string;
} & HTMLAttributes<HTMLDivElement>;

export function SectionDivider({ label, className, ...props }: SectionDividerProps) {
  return (
    <div className={clsx("flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-[var(--text-xsoft)]", className)} {...props}>
      <span className="h-px flex-1 bg-[var(--glass-border)]" />
      {label ? <span>{label}</span> : null}
      <span className="h-px flex-1 bg-[var(--glass-border)]" />
    </div>
  );
}
