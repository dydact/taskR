import clsx from "clsx";
import type { HTMLAttributes, ReactNode } from "react";

export type EmptyStateProps = {
  title?: string;
  description?: string;
  actions?: ReactNode;
} & HTMLAttributes<HTMLDivElement>;

export function EmptyState({
  title = "Nothing here yet",
  description = "Once items appear, you'll see them in this panel.",
  actions,
  className,
  ...props
}: EmptyStateProps) {
  return (
    <div
      className={clsx(
        "flex flex-col items-center justify-center gap-3 rounded-3xl border border-dashed border-[var(--glass-border)] bg-white/40 p-6 text-sm text-[var(--text-soft)] dark:bg-slate-900/60",
        className
      )}
      {...props}
    >
      <p className="text-base font-semibold text-[var(--text-strong)]">{title}</p>
      <p className="text-center text-xs uppercase tracking-[0.3em] text-[var(--text-xsoft)]">{description}</p>
      {actions ? <div className="mt-2 flex items-center gap-2">{actions}</div> : null}
    </div>
  );
}
