import clsx from "clsx";
import type { ReactNode } from "react";

import { PanelHeader, type PanelHeaderProps } from "./PanelHeader";
import { LoadingState } from "./LoadingState";
import { ErrorState } from "./ErrorState";
import { EmptyState } from "./EmptyState";

export type PanelContainerProps = {
  header: PanelHeaderProps;
  isLoading?: boolean;
  error?: string | null;
  empty?: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
  children?: ReactNode;
  className?: string;
};

export function PanelContainer({
  header,
  isLoading,
  error,
  empty,
  emptyTitle,
  emptyDescription,
  children,
  className,
}: PanelContainerProps) {
  return (
    <div className={clsx("glass-panel flex h-full flex-col gap-4 rounded-[32px] border border-[var(--glass-border)] p-4", className)}>
      <PanelHeader {...header} />
      <div className="relative flex flex-1 flex-col">
        {isLoading ? (
          <div className="absolute inset-0 z-10 flex items-center justify-center backdrop-blur-sm">
            <LoadingState />
          </div>
        ) : null}
        {error ? (
          <ErrorState description={error} className="mt-4" onRetry={header.onClose} />
        ) : empty ? (
          <EmptyState title={emptyTitle} description={emptyDescription} className="mt-4" />
        ) : (
          <div className="flex-1 overflow-y-auto">{children}</div>
        )}
      </div>
    </div>
  );
}
