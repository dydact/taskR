import clsx from "clsx";
import type { HTMLAttributes, ReactNode } from "react";

export type PanelHeaderProps = {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  actions?: ReactNode;
  onClose?: () => void;
} & HTMLAttributes<HTMLDivElement>;

export function PanelHeader({ title, subtitle, icon, actions, onClose, className, ...props }: PanelHeaderProps) {
  return (
    <header
      className={clsx(
        "flex items-start justify-between gap-4 rounded-3xl border border-[var(--glass-border)] bg-white/60 px-5 py-4 dark:bg-slate-900/60",
        className
      )}
      {...props}
    >
      <div className="flex items-center gap-3">
        {icon ? <div className="text-[var(--accent)]">{icon}</div> : null}
        <div className="space-y-1">
          <p className="text-sm uppercase tracking-[0.3em] text-[var(--text-xsoft)]">{subtitle}</p>
          <h3 className="text-lg font-semibold text-[var(--text-strong)]">{title}</h3>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {actions}
        {onClose ? (
          <button
            type="button"
            onClick={onClose}
            className="h-8 w-8 rounded-full border border-[var(--glass-border)] text-[var(--text-soft)] transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
            aria-label="Close panel"
          >
            ×
          </button>
        ) : null}
      </div>
    </header>
  );
}
