import clsx from "clsx";
import type { HTMLAttributes } from "react";

export type StatusIndicatorProps = {
  tone?: "success" | "warning" | "danger" | "info";
  label: string;
} & HTMLAttributes<HTMLSpanElement>;

const TONE_CLASSNAMES: Record<NonNullable<StatusIndicatorProps["tone"]>, string> = {
  success: "bg-emerald-500/20 text-emerald-200",
  warning: "bg-amber-500/20 text-amber-200",
  danger: "bg-rose-500/20 text-rose-200",
  info: "bg-sky-500/20 text-sky-200",
};

export function StatusIndicator({ tone = "info", label, className, ...props }: StatusIndicatorProps) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-[0.3em]",
        TONE_CLASSNAMES[tone],
        className
      )}
      {...props}
    >
      <span className="h-2 w-2 rounded-full bg-current" />
      {label}
    </span>
  );
}
