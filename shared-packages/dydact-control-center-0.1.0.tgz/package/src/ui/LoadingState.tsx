import clsx from "clsx";
import type { HTMLAttributes } from "react";

export type LoadingStateProps = {
  message?: string;
} & HTMLAttributes<HTMLDivElement>;

export function LoadingState({ message = "Loading...", className, ...props }: LoadingStateProps) {
  return (
    <div
      className={clsx(
        "flex w-full flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-[var(--glass-border)] bg-white/40 p-6 text-sm text-[var(--text-soft)] dark:bg-slate-900/50",
        className
      )}
      {...props}
    >
      <div className="h-6 w-6 animate-spin rounded-full border-2 border-[var(--accent)] border-t-transparent" />
      <span>{message}</span>
    </div>
  );
}
