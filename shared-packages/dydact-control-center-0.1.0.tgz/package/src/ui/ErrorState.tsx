import clsx from "clsx";
import type { HTMLAttributes } from "react";

export type ErrorStateProps = {
  title?: string;
  description?: string;
  actionLabel?: string;
  onRetry?: () => void;
} & HTMLAttributes<HTMLDivElement>;

export function ErrorState({
  title = "Something went wrong",
  description = "Please try again or contact support if the issue persists.",
  actionLabel = "Retry",
  onRetry,
  className,
  ...props
}: ErrorStateProps) {
  return (
    <div
      className={clsx(
        "flex w-full flex-col items-center justify-center gap-3 rounded-3xl border border-dashed border-rose-200 bg-rose-50/80 p-6 text-sm text-rose-700 dark:border-rose-900 dark:bg-rose-900/40 dark:text-rose-200",
        className
      )}
      {...props}
    >
      <p className="text-base font-semibold">{title}</p>
      <p className="text-center text-xs uppercase tracking-[0.3em]">{description}</p>
      {onRetry ? (
        <button
          type="button"
          className="rounded-full border border-rose-400 px-4 py-1 text-xs font-semibold uppercase tracking-[0.3em] hover:bg-rose-100"
          onClick={onRetry}
        >
          {actionLabel}
        </button>
      ) : null}
    </div>
  );
}
