import clsx from "clsx";
import type { HTMLAttributes } from "react";

export type CardProps = HTMLAttributes<HTMLDivElement>;

export function Card({ className, children, ...props }: CardProps) {
  return (
    <div
      className={clsx(
        "rounded-[32px] border border-white/10 bg-white/5 p-6 shadow-[0_40px_120px_rgba(15,23,42,0.35)] backdrop-blur-xl dark:bg-[#0f1526]/70",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardHeader({ className, children, ...props }: CardProps) {
  return (
    <header className={clsx("flex flex-col gap-2", className)} {...props}>
      {children}
    </header>
  );
}

export function CardBody({ className, children, ...props }: CardProps) {
  return (
    <div className={clsx("flex flex-col gap-4", className)} {...props}>
      {children}
    </div>
  );
}

export function CardFooter({ className, children, ...props }: CardProps) {
  return (
    <footer className={clsx("mt-4 flex items-center gap-3", className)} {...props}>
      {children}
    </footer>
  );
}
