import React from 'react';

export type ToolBlock = { name?: string; data: any };
export type CardProvider = {
  name: string;
  match: (blk: ToolBlock) => boolean;
  render: (blk: ToolBlock) => React.ReactNode;
};

const providers: CardProvider[] = [];

export function registerCard(p: CardProvider) {
  const existing = providers.find((x) => x.name === p.name);
  if (existing) return; // idempotent
  providers.push(p);
}

export function getCardProviders() {
  return providers.slice();
}

