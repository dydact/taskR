import React from 'react';

type MemoryItem = { id?: string; role?: string; content?: string; created_at?: string | number; [k: string]: unknown };
type SearchItem = { title?: string; url?: string | null; snippet?: string; provider?: string };

export function MemoryItemsCard({ items }: { items: MemoryItem[] }) {
  return (
    <div style={{ border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.04)', borderRadius: 16, padding: 12, margin: '8px 0' }}>
      <div style={{ fontSize: 12, letterSpacing: '.25em', textTransform: 'uppercase', color: '#a7b0c0' }}>Memory Items</div>
      <ul style={{ marginTop: 8, display: 'grid', gap: 8 }}>
        {items.map((it, idx) => (
          <li key={it.id || idx} style={{ fontSize: 14, color: '#e8eefb' }}>
            <div style={{ opacity: 0.75, fontSize: 12 }}>{it.role || 'item'}</div>
            <div>{(it.content || '').toString().slice(0, 280)}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function SearchResultsCard({ items }: { items: SearchItem[] }) {
  return (
    <div style={{ border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.04)', borderRadius: 16, padding: 12, margin: '8px 0' }}>
      <div style={{ fontSize: 12, letterSpacing: '.25em', textTransform: 'uppercase', color: '#a7b0c0' }}>Search Results</div>
      <ul style={{ marginTop: 8, display: 'grid', gap: 8 }}>
        {items.map((it, idx) => (
          <li key={idx} style={{ fontSize: 14, color: '#e8eefb' }}>
            <div>
              {it.url ? (
                <a href={it.url} target="_blank" rel="noreferrer" style={{ color: '#6ea8ff', textDecoration: 'none' }}>
                  {it.title || it.url}
                </a>
              ) : (
                <span>{it.title || 'Result'}</span>
              )}
              {it.provider && <span style={{ marginLeft: 8, fontSize: 12, opacity: 0.7 }}>— {it.provider}</span>}
            </div>
            {it.snippet && <div style={{ opacity: 0.85, fontSize: 13, marginTop: 2 }}>{it.snippet}</div>}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function inferCard(payload: any): 'memory' | 'search' | 'none' {
  const data = payload?.items ? payload : payload?.data ? payload.data : null;
  if (!data) return 'none';
  const items = Array.isArray(data.items) ? data.items : [];
  if (!items.length) return 'none';
  const first = items[0];
  if ('snippet' in (first || {}) || 'provider' in (first || {})) return 'search';
  return 'memory';
}

