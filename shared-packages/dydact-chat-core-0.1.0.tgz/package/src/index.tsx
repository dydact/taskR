import React, { useEffect, useMemo, useState } from 'react';
import { MemoryItemsCard, SearchResultsCard, inferCard } from './toolCards';
import Header from './components/Header';
import { getCardProviders } from './registry';

export type Message = { role: 'system' | 'user' | 'assistant'; content: string };

export type DydactChatConfig = {
  apiBase?: string; // defaults to /api/openai/chat proxy in host app
  tenant?: string; // x-tenant-id
  model?: string; // default 'qwen2.5'
};

export function DydactChat(props: { config?: DydactChatConfig, showHeader?: boolean }) {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'system', content: 'Tools are available and may be invoked automatically. Data stays local.' },
  ]);
  const [busy, setBusy] = useState(false);
  const [toolBlocks, setToolBlocks] = useState<Array<{ name?: string; data: any }>>([]);

  // Listen for tool_result events from Insight SSE to render nested widgets
  useEffect(() => {
    let es: EventSource | null = null;
    try {
      es = new EventSource('/api/insight/events');
      es.onmessage = (ev) => {
        try {
          const data = JSON.parse(ev.data || '{}');
          if (data?.type === 'info' && data?.event === 'tool_result') {
            setToolBlocks((prev) => prev.concat({ name: data?.name, data: data?.data }));
          }
        } catch { /* ignore */ }
      };
    } catch { /* ignore */ }
    return () => { try { es?.close(); } catch { /* ignore */ } };
  }, []);

  async function send(text: string) {
    const user = { role: 'user' as const, content: text };
    setMessages((m) => [...m, user, { role: 'assistant', content: '' }]);
    setBusy(true);
    try {
      const res = await fetch('/api/openai/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: props.config?.model || 'qwen2.5', stream: true, messages: [...messages, user] })
      });
      if (!res.body) throw new Error('no stream');
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        const parts = chunk.split(/\n\n/);
        for (const block of parts) {
          const line = block.split('\n').find((l) => l.startsWith('data:'))?.slice(5).trim();
          if (!line || line === '[DONE]') continue;
          try {
            const json = JSON.parse(line);
            const delta = json?.choices?.[0]?.delta?.content;
            if (delta) setMessages((prev) => {
              const next = prev.slice();
              const last = next[next.length - 1];
              if (last?.role === 'assistant') next[next.length - 1] = { ...last, content: (last.content || '') + delta };
              return next;
            });
          } catch { /* ignore */ }
        }
      }
    } catch (e) {
      setMessages((m) => [...m, { role: 'assistant', content: `Error: ${(e as Error).message}` }]);
    } finally {
      setBusy(false);
    }
  }

  const providers = getCardProviders();

  return (
    <div style={{ display: 'grid', gap: 12 }}>
      {props.showHeader !== false && <Header />}
      <div>
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 8 }}>
            <div style={{ opacity: 0.6, fontSize: 12 }}>{m.role}</div>
            <div style={{ whiteSpace: 'pre-wrap' }}>{m.content}</div>
          </div>
        ))}
        {toolBlocks.map((blk, i) => {
          // Try registry first
          for (const p of providers) {
            try {
              if (p.match?.(blk) === true) return <React.Fragment key={`p-${i}`}>{p.render(blk)}</React.Fragment>;
            } catch { /* ignore */ }
          }
          // Fallback inference
          const card = inferCard(blk.data);
          if (card === 'search') return <SearchResultsCard key={`s-${i}`} items={(blk.data?.items) || []} />;
          if (card === 'memory') return <MemoryItemsCard key={`m-${i}`} items={(blk.data?.items) || []} />;
          return null;
        })}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); const el = e.currentTarget.elements.namedItem('q') as HTMLTextAreaElement; const v = el.value.trim(); if (v) { el.value=''; send(v); } }}>
        <textarea name="q" rows={3} disabled={busy} placeholder="Type a message..." style={{ width: '100%', borderRadius: 8, padding: 8 }} />
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 6 }}>
          <button type="submit" disabled={busy} style={{ padding: '6px 10px' }}>Send</button>
        </div>
      </form>
    </div>
  );
}

export default DydactChat;
