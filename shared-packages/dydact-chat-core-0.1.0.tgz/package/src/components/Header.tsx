"use client";

import React, { useEffect, useState } from 'react';

function ToolsPill() {
  const [count, setCount] = useState<number | null>(null);
  useEffect(() => {
    let alive = true;
    fetch('/api/insight/tools').then(r => r.json()).then(j => {
      if (!alive) return;
      const c = Array.isArray(j?.tools) ? j.tools.length : 0;
      setCount(c);
    }).catch(() => setCount(null));
    return () => { alive = false; };
  }, []);
  const label = count === null ? 'Tools' : (count > 0 ? `Tools · ${count}` : 'Tools unavailable');
  return (
    <span style={{
      background: count && count > 0 ? 'rgba(26,188,156,0.15)' : 'rgba(255,255,255,0.08)',
      border: '1px solid rgba(255,255,255,0.12)',
      padding: '6px 10px',
      borderRadius: 999,
      fontSize: 11,
      letterSpacing: '.15em',
      fontWeight: 700,
      color: count && count > 0 ? '#2ecc71' : '#d9e1ff',
    }}>{label}</span>
  );
}

function ModelChip() {
  const [model, setModel] = useState<string | null>(null);
  useEffect(() => {
    const ctrl = new AbortController();
    const tenant = (typeof process !== 'undefined' ? (process.env?.NEXT_PUBLIC_TENANT_ID as string | undefined) : undefined) || 'demo';
    fetch('/api/insight/config', { headers: { 'x-tenant-id': tenant }, signal: ctrl.signal })
      .then((r) => r.json())
      .then((cfg) => {
        try {
          const profiles = cfg?.profiles || {};
          const reasoning = profiles?.reasoning || [];
          if (Array.isArray(reasoning) && reasoning.length) setModel(reasoning[0]);
        } catch { /* ignore */ }
      }).catch(() => void 0);
    let es: EventSource | null = null;
    try {
      es = new EventSource('/api/insight/events');
      es.onmessage = (ev) => {
        try {
          const data = JSON.parse(ev.data || '{}');
          if (data?.type === 'info' && data?.event === 'model' && typeof data?.model === 'string') setModel(data.model);
        } catch { /* ignore */ }
      };
    } catch { /* ignore */ }
    return () => { ctrl.abort(); try { es?.close(); } catch { /* ignore */ } };
  }, []);
  if (!model) return null;
  return (
    <span style={{
      background: 'rgba(255,255,255,0.08)',
      border: '1px solid rgba(255,255,255,0.12)',
      padding: '6px 10px',
      borderRadius: 999,
      fontSize: 11,
      letterSpacing: '.15em',
      fontWeight: 700,
      color: '#d9e1ff',
    }}>{model}</span>
  );
}

export default function Header() {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
      <h1 style={{ fontSize: 16, letterSpacing: '.25em', textTransform: 'uppercase', color: '#a7b0c0' }}>Dydact Chat</h1>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <ToolsPill />
        <ModelChip />
      </div>
    </div>
  );
}

